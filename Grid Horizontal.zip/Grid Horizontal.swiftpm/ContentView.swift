import SwiftUI
struct ContentView: View {
    @State private var gridColumns: [GridItem] = [GridItem(.adaptive(minimum: 200), spacing: 0)]
    var body: some View {
        ScrollView(.horizontal) {
            LazyHGrid(rows: gridColumns, spacing: 10) {
                Rectangle()
                    .frame(width: 400, height: 200)
                    .foregroundColor(.red)
                Rectangle()
                    .frame(width: 400, height: 200)
                    .foregroundColor(.green)
                Rectangle()
                    .frame(width: 400, height: 200)
                    .foregroundColor(.gray)
                Rectangle()
                    .frame(width: 400, height: 200)
                    .foregroundColor(.orange)
                Rectangle()
                    .frame(width: 400, height: 200)
                    .foregroundColor(.blue)
                Rectangle()
                    .frame(width: 400, height: 200)
                    .foregroundColor(.cyan)
            }
            .padding()
        }
        .frame(height: 450)
    }
}

